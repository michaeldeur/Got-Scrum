import DataStore from "@seald-io/nedb";
import * as path from "path";
import { UserStory } from "../js/UserStory";
import { Card } from "../js/Cards";

class StoryDataAccess {
    private db: DataStore;
    private static dataAccess: StoryDataAccess;
    private constructor() {
        this.db = new DataStore({
            filename: path.join(__dirname, "stories.db"),
            autoload: true,
            // inMemoryOnly: true,
        });
    }

    public static getDataAccess(): StoryDataAccess {
        if (StoryDataAccess.dataAccess === undefined) {
            this.dataAccess = new StoryDataAccess();
        }
        return StoryDataAccess.dataAccess;
    }

    public async addStory(story: UserStory): Promise<UserStory> {
        return await this.db.insertAsync(story);
    }


    public async getStory(ID: number): Promise<UserStory> {
        return await this.db.findOneAsync({ id: ID });
    }
    public async getStories(): Promise<UserStory[]> {
        return await this.db.findAsync({});
    }

    public removeID(ID: number) {
        for (let index = ID + 1; index <= this.db.getAllData().length; index++) {
            StoryDataAccess.getDataAccess().updateID(index, index - 1);
        }
    }
    public updateID(prevID: number, ID: number) {
        let stories = this.db.getAllData().sort((a, b) => parseInt(a.id!) - parseInt(b.id!));
        if (stories.at(ID)) {
            stories.forEach((story, i) => {
                if (prevID < ID && story.id > prevID && story.id <= ID) {
                    story.id = (story.id - 1).toString();
                } else if (prevID > ID && story.id < prevID && story.id >= ID) {
                    story.id = (parseInt(story.id) + 1).toString();
                }
            })
            if (stories.at(prevID)) {
                stories.at(prevID)!.id = ID.toString();
            }
        }
        return stories.at(ID) as UserStory;
    }

    public async saveStory(story: UserStory): Promise<UserStory> {
        return await this.db
            .updateAsync({ _id: story._id }, story).then(() => {

                return story;
            });
    }


    public async removeStory(story: UserStory): Promise<number> {
        return await this.db.removeAsync({ storyNum: story.storyNum }, {});
    }
}
class CardDataAccess {
    private db: DataStore;
    private static dataAccess: CardDataAccess;
    private constructor() {
        this.db = new DataStore({
            filename: path.join(__dirname, "cards.db"),
            autoload: true
        });
    }

    public static getDataAccess(): CardDataAccess {
        if (CardDataAccess.dataAccess === undefined) {
            this.dataAccess = new CardDataAccess();
        }
        return CardDataAccess.dataAccess;
    }

    public async addCard(card: Card): Promise<Card> {
        return await this.db.insertAsync(card);
    }


    public async getCard(ID: string): Promise<Card> {
        return await this.db.findOneAsync({ _id: ID });
    }
    public async getCards(): Promise<Card[]> {
        return await this.db.findAsync({});
    }


    public async saveCard(card: Card): Promise<Card> {
        return await this.db
            .updateAsync({ _id: card._id }, card).then(() => {
                return card;
            });
    }


    public async removeCard(card: Card): Promise<number> {
        return await this.db.removeAsync({ _id: card._id }, {});
    }
}

class EstimatedStoryDataAccess {
    private db: DataStore;
    private static dataAccess: EstimatedStoryDataAccess;
    private constructor() {
        this.db = new DataStore({
            filename: path.join(__dirname, "estimations.db"),
            autoload: true,
            // inMemoryOnly: true,
        });
    }

    public static getDataAccess(): EstimatedStoryDataAccess {
        if (EstimatedStoryDataAccess.dataAccess === undefined) {
            this.dataAccess = new EstimatedStoryDataAccess();
        }
        return EstimatedStoryDataAccess.dataAccess;
    }

    public async addStory(story: UserStory): Promise<UserStory> {
        return await this.db.insertAsync(story);
    }


    public async getStory(ID: string): Promise<UserStory> {
        return await this.db.findOneAsync({ _id: ID });
    }
    public async getStories(): Promise<UserStory[]> {
        return await this.db.findAsync({});
    }


    public async saveStory(story: UserStory): Promise<UserStory> {
        return await this.db
            .updateAsync({ _id: story._id }, story).then(() => {
                return story;
            });
    }


    public async removeStory(story: UserStory): Promise<number> {
        return await this.db.removeAsync({ _id: story._id }, {});
    }
}

export { StoryDataAccess, CardDataAccess, EstimatedStoryDataAccess };